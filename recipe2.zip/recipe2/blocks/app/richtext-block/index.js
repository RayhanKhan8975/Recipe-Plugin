
const { registerBlockType }         =   wp.blocks;
const { RichText }                  =   wp.blockEditor;
const { __ }                        =   wp.i18n;
console.log('Hello');
registerBlockType( 'udemy/rich-text', {
    title:                              __( 'Rich Text Example', 'recipe' ),
    description:                        __( 'Rich text example', 'recipe' ),
    category:                           'common',
    icon:                               'welcome-learn-more',
    attributes: {
        message:{
            type:           'array',
            source:         'children',
            selector:       '.message-ctr'
        }
    },
    edit: ( props ) => {
        return (
            <div className={ props.className }>
                <h3>Rich Text Example Block</h3>
            <RichText
            tagName = 'div'
            multiline = 'p'
            placeholder = {__('Add your content here', 'recipe2')}
            onChange    = {(new_val) => {
                 props.setAttribute({message:new_val})
            }}
            value = {props.attributes.message}
            /> 
            </div>
        );
    },
    save: ( props ) => {
        return (
           <div>
               <h1>Rich Text Heading</h1>
               <div className='message-ctr' >
                   {props.attributes.message}
               </div>
           </div>
            )
    }
});