const {registerBlockType }          = wp.blocks;
const { __ }                        = wp.i189;
const {InspectorControls,
        BlockControls, 
        AlignmentToolbar}           = wp.editor;
const {PanelBody, PanelRow,
 TextControl,SelectControl}         = wp.components;
registerBlockType('udemy/recipe2',{
	title      : __('Recipe', 'recipe2'),
	Description: __('Provides a short summary of a recipe','recipe2'),
	category   :          'common',
	icons      :          'wp-welcome-learn-more',
	keywords   :   [
    __('Food', 'recipe2'),
    __('Ingredients', 'recipe2'),
    __('Meal Type ',        'recipe2')
	],
	supports   : {
		html:false
	},
    attributes:{
        Ingredients:{
            source: 'text',
            type:   'string',
            selector:'.ingredients-ph'
        },
        cooking_time:{
            source: 'text',
            type:   'string',
            selector:'.cooking_time-ph'
        },
        utensils:{
            source: 'text',
            type:   'string',
            selector:'.utensils-ph'
        },
        cooking_experience:{
            source: 'text',
            type:   'string',
            selector:'.cooking_experience-ph'
        },
        meal_type:{
            source: 'text',
            type:   'string',
            selector:'.meal_type-ph'
        },
        text_alignment:{
            type:'string'
        }
    }
    ,
	edit:()=>{
 return[
    <InspectorControls>
    	<PanelBody title={__('Basics', 'recipe2')} >
    		<PanelRow>
    	     <p>{__('Configure this contents of your block here')}</p>		 
    		</PanelRow>
    		<TextControl
             label = {__('Ingredients', 'recipe2')}
             help  = {__('helps you write Ingredients', 'recipe2')}
             value = {props.attributes.Ingredients}
             onChange = {(new_val) => {
             props.setAttributes({Ingredients:new_val})
             }}
    		/>

    		<TextControl
             label = {__('COOKING_TIME', 'recipe2')}
             help  = {__('COOKING_TIME Required', 'recipe2')}
             value = {props.attributes.cooking_time}
             onChange = {(new_val) => {
             props.setAttributes({cooking_time:new_val})
             }}
    		/>
    		<TextControl
             label = {__('Utensils', 'recipe2')}
             help  = {__('What Utensils are required?', 'recipe2')}
             value = {props.attributes.utensils}
             onChange = {(new_val) => {
             props.setAttributes({utensils:new_val})
             }}
    		/>
            <SelectControl
             label = {__('Experience', 'recipe2')}
             help  = {__('What Experience is required?', 'recipe2')}
             value = {props.attributes.cooking_experience}
             options = {[
                {value:'Beginner', label:"Beginner"},
                {value:'Intermediate', label:"Intermediate"},
                {value:'Expert', label:"Expert"}
             	]

             }
             onChange = {(new_val) => {
             props.setAttributes({cooking_experience:new_val})
             }}

            />
            <SelectControl
             label = {__('Meal_Type', 'recipe2')}
             help  = {__('What Meal is required?', 'recipe2')}
             value = {props.attributes.meal_type}
             options = {[
                {value:'BreakFast', label:"BreakFast"},
                {value:'Lunch', label:"Lunch"},
                {value:'Dinner', label:"Dinner"}
             	]

             }
             onChange = {(new_val) => {
             props.setAttributes({meal_type:new_val})
             }}

            />
    		    	</PanelBody>
    </InspectorControls>
 ,
    <div>
    <BlockControls>
        <AlignmentToolbar
         value={props.attributes.text_alignment}
         onChange = {(new_val) => {
          props.setAttributes({text_alignment:new_val})
         }}
         />
    </BlockControls>
                <ul class="list-unstyled" style={{textAlign:props.attributes.text_alignment}} >
    <li>
    <strong>
    Ingredients:
     </strong>
   
    <span className='ingredients-ph' >
     {props.attributes.Ingredients}    
    </span>
    </li>
    <li><strong>Cooking Time: </strong>
    <span className='cooking_time-ph' >
    
    {props.attributes.cooking_time}
    </span></li>
    <li><strong>Utensils: </strong>
    <span className='utensils-ph' >
    {props.attributes.utensils}
    </span> </li>
    <li><strong>Cooking Experience: </strong>
    <span className='cooking_experience-ph' >
     {props.attributes.cooking_experience}
    </span></li>
    <li><strong>Meal Type: </strong>
    <span className='meal_type-ph' >
    {props.attributes.meal_type}
    </span> </li>
</ul>
    </div>
]
	},
	save:()=>{
    return (<ul class="list-unstyled" style={{textAlign:props.attributes.text_alignment}} >
    <li>
    <strong>
    Ingredients:
     </strong>
   
    <span className='ingredients-ph' >
     {props.attributes.Ingredients}    
    </span>
    </li>
    <li><strong>Cooking Time: </strong>
    <span className='cooking_time-ph' >
    
    {props.attributes.cooking_time}
    </span></li>
    <li><strong>Utensils: </strong>
    <span className='utensils-ph' >
    {props.attributes.utensils}
    </span> </li>
    <li><strong>Cooking Experience: </strong>
    <span className='cooking_experience-ph' >
     {props.attributes.cooking_experience}
    </span></li>
    <li><strong>Meal Type: </strong>
    <span className='meal_type-ph' >
    {props.attributes.meal_type}
    </span> </li>
</ul>);
})