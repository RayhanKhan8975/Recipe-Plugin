
import block_icons from '../icon/index';
import './editor.scss';
const {registerBlockType}         = wp.blocks;
const { __ }                      = wp.i18n;
const { InspectorControls,
        BlockControls,
        AlignmentToolbar,
        BlockAlignmentToolbar }       = wp.blockEditor;
const { PanelBody, PanelRow,
 TextControl, SelectControl}     = wp.components;
registerBlockType('udemy/recipe2', {
	title:                __( 'Recipe', 'recipe2'),
    description :         __('Provides a short summary of a recipe', 'recipe2'),

    category    :         'common',
    icon        :        'welcome-learn-more',
    keywords    :         [
    __('Food', 'recipe2'),
    __('Ingredients', 'recipe2'),
    __('Meal Type', 'recipe2'),
    ]
    
    ,
    
    support     : {
    html        : false
    },
    attributes  : {
        ingredients: {
             source:'text',
             type:'string',
             selector:'.ingredients-ph'

        }
        ,
        cooking_time: {
             source:'text',
             type:'string',
             selector:'.cooking_time-ph'
        }
        ,
        utensils: {
             source:'text',
             type:'string',
             selector:'.utensils-ph'
        }
        ,
        cooking_experience: {
             source:'text',
             type:'string',
             selector:'.cooking_experience-ph',
             default:'Beginner'
        }
        ,
        meal_type: {
             source:'text',
             type:'string',
             selector:'.meal_type-ph',
             default: 'BreakFast'
        }
        ,
        text_alignment:{
            type:'text'
        }
        ,
        block_alignment:{
            type: 'string',
            default:'wide'
        }
    }
    ,
     getEditWrapperProps:({block_alignment}) => {
         if ('left' === block_alignment || 'full' === block_alignment ||'right' === block_alignment ) {
         return {'data-align': block_alignment};
         }
     },
    edit : (props) => {
        return [
        <InspectorControls>

         <PanelBody title={__('Basics', 'recipe2')} >
             <PanelRow>
            <p>{__('Configure the contents of the blog here', 'recipe2')} </p>                 
             </PanelRow>
             <TextControl 
             label={__('Ingredients', 'recipe2')}
             help ={__('Ex: tomatoes, lattices, olive oil, ', 'recipe2')}
             value = {props.attributes.ingredients}
             onChange ={ (new_val)=>{
                 props.setAttributes( {ingredients: new_val} )

             }  }
              />
              <TextControl 
             label={__('Cooking Time', 'recipe2')}
             help ={__('How long will it take?', 'recipe2')}
             value = {props.attributes.cooking_time}
             onChange ={ (new_val)=>{
                 props.setAttributes( {cooking_time: new_val} )
             }  }
              />
              <TextControl 
             label={__('Utensils', 'recipe2')}
             help ={__('Ex: spoon, knife, pots, pans  ', 'recipe2')}
             value = {props.attributes.utensils}
             onChange ={ (new_val)=>{
                 props.setAttributes( {utensils: new_val} )
             }  }
              />
              <SelectControl
              label = {__('Cooking Experience', 'recipe2')}
              help  = {__('How skilled the reader should be?', 'recipe2')}
              value = {props.attributes.cooking_experience}
              options = {[
                  { value: 'Beginner', label : 'Beginner' },
                  { value: 'Intermediate', label : 'Intermediate' },
                  { value: 'Expert', label : 'Expert' }
                  ]}
              onChange = {(new_val)=>{
                 props.setAttributes( {cooking_experience: new_val} )
              }}    
              />
             <SelectControl
              label = {__('Meal Type', 'recipe2')}
              help  = {__('When is this to be eaten?', 'recipe2')}
              value = {props.attributes.meal_type}
              options = {[
                  { value: 'BreakFast', label : 'BreakFast' },
                  { value: 'Lunch', label : 'Lunch' },
                  { value: 'Dinner', label : 'Dinner' }
                  ]}
              onChange = {(new_val)=>{
                 props.setAttributes( {meal_type: new_val} )
              }}    
              />
            
         </PanelBody>   
        </InspectorControls>,
                    <div className={props.className} >
          <BlockControls>
          <BlockAlignmentToolbar
           value={ props.attributes.block_alignment }
           onChange = {(new_val)=> {
               props.setAttributes({block_alignment:new_val})
           }}

          />
              <AlignmentToolbar 
               value={props.attributes.text_alignment}
               onChange = {(new_val)=> {
                 props.setAttributes({text_alignment:new_val})
               }}
               />
          </BlockControls>
<ul className = "list-unstyled"
    style = {{textAlign : props.attributes.text_alignment}}
>
    <li>
    <strong>
     {__('Ingredients:', 'recipe2')}
       </strong>
       <span className='ingredients-ph' >
       {props.attributes.ingredients}
       </span>
     </li>
    <li>
    <strong>
    {__('Cooking Time:', 'recipe2')}
     </strong>
       <span className='cooking_time-ph' >
             {props.attributes.cooking_time }
       </span>
      </li>
    <li>
    <strong>
    {__('Utensils:', 'recipe2')}
     </strong>
       <span className='utensils-ph' >
           {props.attributes.utensils}
       </span>
       
      </li>
    <li>
    <strong>
    {__('Cooking Experience:', 'recipe2')}
    </strong>
       <span className='cooking_experience-ph' >
           
       {props.attributes.cooking_experience}
       </span>
     </li>
    <li>
    <strong>
    {__('Meal Type:', 'recipe2')}
     </strong>
       <span className='meal_type-ph' >           
       {props.attributes.meal_type}
       </span>
      </li>
</ul>
            </div>
            ]
    }
    ,
    save :      (props) => {
        
return ( 
     <div className={ `align${props.attributes.block_alignment}`} >
             <ul>
    <li>
    <strong>
     {__('Ingredients:', 'recipe2')}
       </strong>
       <span className='ingredients-ph' >
       {props.attributes.ingredients}
       </span>
     </li>
    <li>
    <strong>
    {__('Cooking Time:', 'recipe2')}
     </strong>
       <span className='cooking_time-ph' >
             {props.attributes.cooking_time }
       </span>
      </li>
    <li>
    <strong>
    {__('Utensils:', 'recipe2')}
     </strong>
       <span className='utensils-ph' >
           {props.attributes.utensils}
       </span>
       
      </li>
    <li>
    <strong>
    {__('Cooking Experience:', 'recipe2')}
    </strong>
       <span className='cooking_experience-ph' >
           
       {props.attributes.cooking_experience}
       </span>
     </li>
    <li>
    <strong>
    {__('Meal Type:', 'recipe2')}
     </strong>
       <span className='meal_type-ph' >           
       {props.attributes.meal_type}
       </span>
      </li>
</ul>
     </div>
);
       
    }
})