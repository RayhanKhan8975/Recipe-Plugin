<?php

function r_admin_notices(){
	if (!get_option( 'r_pending_recipe_notice' )) {
		return;
	}
	?>
<div class="notice notice-warning is-dismissable" id="r-recipe-pending-notice" >
	<p>
		<?php _e( 'You have couple of recipes to review', 'recipe2' ); ?>
	</p>
</div>
	<?php
}