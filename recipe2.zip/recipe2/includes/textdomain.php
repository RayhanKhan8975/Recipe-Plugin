<?php

function r_load_text_domain(){
	$plugin_dir           = 'recipe2/lang';
	load_plugin_textdomain( 'recipe2', false,$plugin_dir);
}