(function($){
	$('#recipe_rating').bind('rated', function(){
		$(this).rateit( 'readonly', true );

		var form = {
          action: 'r_rate_recipe',
          rid   : $(this).data('rid'),
          rating: $(this).rateit('value')
		};
		$.post( recipe_obj.ajax_url, form, function(data){
			
		} )
		console.log('rated')
	});

   var feature_frame        = wp.media({
     title:                  'Select or Upload Media',
     button: {
       text:                 'Use this media'
     },
     multiple:false,
   })

   feature_frame.on('select', function(){
     var attachment            = feature_frame.state().get('selection').first().toJSON();
     $("#recipe-img-preview").attr('src', attachment.url);
     $('#r_inputImgID').val(attachment.id);
   })

   $(document).on('click', '#recipe-img-upload-btn', function(e){
      e.preventDefault();
      feature_frame.open();
      console.log('feature_frame')
   })

    $('#recipe-form').on('submit', function(e){
           e.preventDefault();

           $(this).hide();

           $('#recipe-status').html(
           '<div class="alert alert alert-info" >Please Wait! We are submittin your recipe</div>'
             );
           var form =  {
             action:        'r_submit_user_recipe',
             title :         $('#r_inputTitle').val(),
             content:        tinymce.activeEditor.getContent(),
             attachment_id:  $('#r_inputImgID').val()
           }
           $.post( recipe_obj.ajax_url, form, function(data){
               if (data.status == 2) {
                 $('#recipe-status').html(
 '<div class="alert alert alert-success" >Recipe submitted Succesfully</div>'
          
                   );

               }else {
                 $('#recipe-status').html(
 '<div class="alert alert alert-danger" >An Error Occured</div>'
          
                   );
                 $('#recipe-form').show();
               }
           } );

    });

    $(document).on('submit', '#register-form', function(e){
     e.preventDefault();

     $('#register-status').html( '<div class="alert alert alert-info" >Please Wait! We are submittin your recipe</div>'
          )
     $(this).hide();

     var form                  = {
       _wpnonce:                 $("#_wpnonce").val(),
       action:                   "recipe_create_account",
       name:                     $("#register-form-name").val(),
       username:                 $("#register-form-username").val(),
       email:                    $("#register-form-email").val(),
       pass:                     $("#register-form-password").val(),
       confirm_pass:             $("#register-form-repassword").val()
     } ;
     $.post(recipe_obj.ajax_url, form).always(function(data){
       if (data.status == 2) {
          $('#register-status').html( '<div class="alert alert alert-success" > Succesfull </div>'
          );
          location.href             = recipe_obj.home_url;
       }else {
                   $('#register-status').html( '<div class="alert alert alert-danger" > An Error Occured </div>'
          )
       $('#register-form').show();
       }
     })
    })
    $(document).on('submit', '#login-form', function(e){
       e.preventDefault();

       $('#login-status').html(
        '<div class="alert alert alert-info" >Please Wait! While we log you in </div>'
         );
       $(this).hide();

       var form                = {
         _wpnonce:                $('#_wpnonce').val(),
         action:                  'recipe_user_login',
         username:                $('#login-form-username').val(),
         pass:                    $('#login-form-password').val()
       }
       console.log(form);

       $.post(recipe_obj.ajax_url, form).always(function(data){
           if (data.status == 2) {
                    $('#login-status').html(
        '<div class="alert alert alert-info" >Success</div>'
         );
                    location.href             = recipe_obj.home_url;
           }
           else{
                               $('#login-status').html(
        '<div class="alert alert alert-info" >Failed</div>'
         );
                               $('#login-form').show()
           }
       })
    });
})(jQuery);
